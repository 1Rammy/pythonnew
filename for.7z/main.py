# Задание 5
# import math
# a = int(input())
# b = math.factorial(a)
# print(b)
# a = int(input())
# b = 1
# for i in range(1, a+1):
#     b *= i
# print(b)
# задание 4
# for i in range(10,35,5):
#     print(i)
# a = int(input())
# b = int(input())
# c = int(input())
# for i in range(a,b,c):
#     print(i)
# a = random.randint(0,10)
# b = int(input())
# c = 0
# if b != a:
# while c <=10 :
#     if b < a:
#         print("мало")
#         b = int(input())
#     else b > a
#         print("много")
#         b = int(input())
#     elif:
#         