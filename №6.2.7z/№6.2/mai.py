# S = input()
# S0 = input()
# b = S.replace()
# print(b)
# first_str = input()
# list = first_str.replace(':','**')
# h = 0
# for i in range(first_str.__len__()):
#     if first_str[i] == ":":
#         h += 1
# print(list,h)
# first_str = input()
# list = first_str.replace(',','ю')
# h = 0
# for i in range(first_str.__len__()):
#     if first_str[i] == ",":
#         h += 1
# print(list,h)