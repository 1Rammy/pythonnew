# number = 1
# while number < 5:
#     print(f"number = {number}")
#     number += 1
# print("конец программы")
# number = 1
# while number < 5:
#     print(f"number = {number}")
#     number += 1
# else:
#     print(f"number = {number}. Работа цикла завершена")
# print("Работа программы завершена")
# number = 10
# while number < 5:
#     print(f"number = {number}")
#     number += 1
# else:
#     print(f"number = {number}. Работа цикла завершена")
# print("Работа программы завершена")
# i = 1
# j = 1
# while i < 10:
#     while j < 10:
#         print(i * j, end="\t")
#         j += 1
#         print("\n")
#         j = 1
#         i += 1
#         break
import math
a = -math.pi/2
b = math.pi/2
h = math.pi/10
while a < b:
    Y=a**2 * math.cos(a) * math.sin(a)
    a += h
    print(Y)