import math

a = int(input())
z1 = math.sin(math.pi/2+3*a)/1-math.sin(2*a)
z2 = 1/math.tan(5/4*math.pi+3/2*a)
print(z1, z2)