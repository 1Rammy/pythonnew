# easy 2
# # string = "123456789"
# # print("Вывод символов при помощи положительных индексов ")
# # c3 = string[2]
# # print(c3)
# # c5 = string[4]
# # print(c5)
# # c567 = string[4:7]
# # print(c567)
# easy 4
# a = [2, 4, 6, 7, 3, 1]
# print(a[0])
# print(a[-1])
# easy 3
# a = "кот"
# print(a)
# b = a[-1] + a[-2] + a[-3]
# print(b)
# easy 5
# def sum_range(start,end):
#     sum=0
#     if end < start:
#         start, end = end, start
#     for a in range(start,end,1):
#         sum=sum+a
#     return sum
# start = int(input())
# end = int(input())
# print(sum_range(start,end))
# easy 1
# a = int(input())
# # print("ПЕРЕВОД ЧИСЛА",a)
# # print(bin(a), "В ДВОИЧНОЙ.")
# # print(oct(a), "В ВОСЬМЕРИЧНОЙ.")
# # print(hex(a), "В ШЕСТНАДЦАТЕРИЧНОЙ.")